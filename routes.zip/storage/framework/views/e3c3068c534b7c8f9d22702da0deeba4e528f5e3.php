

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-sm-10">

            <?php echo Form::open(['route'=>['post.store'],'method'=>'POST','files'=>true]); ?>


            <div class="jumbotron">
                <div class="form-group">
                    <label for="title">INGRESE TITLE</label>
                    <?php echo Form::text('title',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>
                <div class="form-group">
                    <label for="description">INGRESE DESCRIPTION</label>
                    <?php echo Form::text('description',null ,['class'=>'form-control','maxlength'=>'155']); ?>

                </div>

                <div class="form-group">
                    <label for="nombre">INGRESE NOMBRE</label>
                    <?php echo Form::text('nombre',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="descripcion">INGRESE DESCRIPCIÓN</label>
                    <?php echo Form::textarea('descripcion',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="orden">INGRESE ORDEN</label>
                    <?php echo Form::text('orden',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="categoria_id">ELIJA CATEGORÍA</label>
                    <?php echo Form::select('categoria_id',$categorias,null ,['class'=>'form-control']); ?>

                </div>



                <div class="form-group">
                    <label for="urlfoto">IMAGEN</label> <br>
                    <img src="/img/post/foto.jpg">
                    <?php echo Form::file('urlfoto'); ?>

                </div>

            </div>
            <?php echo Form::submit('GUARDAR',['class'=>'btn btn-success']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\artesanias\resources\views/admin/post/create.blade.php ENDPATH**/ ?>