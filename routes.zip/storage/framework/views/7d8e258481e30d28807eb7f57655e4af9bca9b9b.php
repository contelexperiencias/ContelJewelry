<div class="col-sm-2">
    <ul class="list-group">
        <li class="list-group-item">
            <a href="/admin/configuracion">Configuración</a>
        </li>
        <li class="list-group-item">
            <a href="/admin/categoria">Categorias</a>
        </li>

        <li class="list-group-item">
            <a href="/admin/post">Blog</a>
        </li>

        <li class="list-group-item">
            <a href="/admin/carrusel">Carrusel</a>
        </li>

        <li class="list-group-item">
            <a href="/admin/empresa">Empresa</a>
        </li>



    </ul>
</div><?php /**PATH C:\xampp\htdocs\py_laravel-100\resources\views/admin/submenu.blade.php ENDPATH**/ ?>