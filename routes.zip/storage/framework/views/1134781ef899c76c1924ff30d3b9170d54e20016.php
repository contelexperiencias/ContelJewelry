<div class="col-sm-2">
    <ul class="list-group">
        <li class="list-group-item"><a href="/admin/configuracion">Configuración</a></li>

    </ul>
</div><?php /**PATH C:\xampp\htdocs\artesanias\resources\views/admin/aside.blade.php ENDPATH**/ ?>