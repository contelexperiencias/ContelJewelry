

<?php $__env->startSection('content'); ?>
<div class="container bg-warning">
    <h1 class="pt-4 text-white">NOSOTROS</h1>
    <div class="row">
        <img src="/img/empresa/<?php echo e($empresa->urlsomos); ?>" class="img-fluid">

        
    </div>
    
        <div class="col-sm-12 p-5 mb-5 bg-white">
            <h2>QUIENES SOMOS</h2>
            <?php echo $empresa->somos; ?>


            <div class="row mt-5 mb-5 align-items-center">
                <div class="col-sm-4">
                    <img src="/img/empresa/<?php echo e($empresa->urlmision); ?>" class="img-fluid">
                </div>
                <div class="col-sm-8">
                    <h2 class="text-danger">MISIÓN</h2>
                    <?php echo $empresa->mision; ?>

                </div>
            </div>

            <div class="row mt-5 mb-5 align-items-center">
                
                <div class="col-sm-8">
                    <h2 class="text-danger">VISIÓN</h2>
                    <?php echo $empresa->vision; ?>

                </div>
                <div class="col-sm-4">
                    <img src="/img/empresa/<?php echo e($empresa->urlvision); ?>" class="img-fluid">
                </div>
            </div>


            <div class="row mt-5 mb-5 align-items-center">
                <div class="col-sm-4">
                    <img src="/img/empresa/<?php echo e($empresa->urlhistoria); ?>" class="img-fluid">
                </div>
                <div class="col-sm-8">
                    <h2 class="text-danger">RESEÑA HISTÓRICA</h2>
                    <?php echo $empresa->historia; ?>

                </div>
            </div>


            <div class="row mt-5 mb-5 align-items-center">
                
                <div class="col-sm-8">
                    <h2 class="text-danger">VALORES CORPORATIVOS</h2>
                    <?php echo $empresa->valores; ?>

                </div>
                <div class="col-sm-4">
                    <img src="/img/empresa/<?php echo e($empresa->urlvalores); ?>" class="img-fluid">
                </div>
            </div>



        </div>

        


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\artesanias\resources\views/front/empresa.blade.php ENDPATH**/ ?>