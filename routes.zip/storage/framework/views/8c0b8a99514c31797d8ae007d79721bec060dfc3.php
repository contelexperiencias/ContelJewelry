

<?php $__env->startSection('content'); ?>
<div class="container bg-warning pb-5">
    <div class="row">
        <h1 class="p-3 text-danger mt-5"><?php echo e($categoria->nombre); ?></h1>
        <img src="/img/categoria/<?php echo e($categoria->urlfoto); ?>" class="img-fluid">

    </div>

    
        <?php $__empty_1 = true; $__currentLoopData = $categoria->Producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="row m-5 bg-white p-3 rounded-lg ">
            <div class="col-sm-12">
                <h2 class="text-danger h4"><?php echo e($r->nombre); ?></h2>
            </div>
            <div class="row align-items-center bg-light">
                <div class="col-sm-4">
                    <img src="/img/producto/<?php echo e($r->urlfoto); ?>" class="img-fluid rounded-lg">
                </div>
                <div class="col-sm-8 rounded-lg">
                    <p><?php echo e($r->description); ?></p>
                    <div class="text-right">
                        <a href="/artesanias/<?php echo e($categoria->slug); ?>/<?php echo e($r->slug); ?>" class="btn btn-danger rounded-pill pr-5 pl-5">AMPLIAR</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
        <?php endif; ?>

    
  


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\py_laravel-100\resources\views/front/categoria.blade.php ENDPATH**/ ?>